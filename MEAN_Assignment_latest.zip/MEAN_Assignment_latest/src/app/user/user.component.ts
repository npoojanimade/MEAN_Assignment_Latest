import { Component, OnInit } from '@angular/core';
import {UserRole} from './../Model/app.role.model';
import {UsersCreate} from './../Model/app.users.model';
import {UserCreateService} from './../services/app.usercreate.services';
import {Response} from '@angular/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  users: UsersCreate;
  roles : UserRole;
  userRole: Array<UserRole>;
  // private roles: Array<UserRole>;
    constructor(private roleserv:UserCreateService) {
        this.users = new UsersCreate('', '', '', '');
        this.userRole = new Array<UserRole>();
        this.roles = new UserRole('','','','');
    }
    save(): void {
      console.log("UserData is "+JSON.stringify(this.users))
      this.roleserv.CreateUsers( this.users).subscribe(
       (resp: Response) => {
           this.users = resp.json().data;
           console.log(resp.json().data);
       },
       error => {
           console.log(`Error occured ${error}`);

       }
      );
    }

    clear(): void {
      this.users = new UsersCreate('' , '', '' , '');
    }
  ngOnInit() {
    
    this.roleserv.getRoleData().subscribe(
      (resp:Response) =>{
          this.userRole = resp.json().data;
          console.log("in component"+JSON.stringify(this.userRole));
      },
      error => {
          console.log(`Error occured ${error}`);
          
      }
      
  );
  }
}

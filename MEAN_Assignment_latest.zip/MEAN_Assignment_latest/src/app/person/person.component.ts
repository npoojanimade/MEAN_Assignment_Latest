import { Component, OnInit } from '@angular/core';
import {PersonCreateService} from './../services/app.addperson.services';
import {PersonInfo} from './../Model/app.person.model';
import {Response} from '@angular/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

  role: PersonInfo;
   private roles: Array<PersonInfo>;
    constructor(private serve: PersonCreateService) {
        // this.role = new PersonInfo( 0 , '', '','','','','','','','','','','','','','','');
    }
    save(): void {
      console.log("UserData is "+JSON.stringify(this.roles))
      this.serve.CreatePerson(this.roles).subscribe(
       (resp: Response) => {
           this.roles = resp.json().data;
           console.log(resp.json().data);
       },
       error => {
           console.log(`Error occured ${error}`);

       }
      );
    }
    
  ngOnInit() {
  }

}

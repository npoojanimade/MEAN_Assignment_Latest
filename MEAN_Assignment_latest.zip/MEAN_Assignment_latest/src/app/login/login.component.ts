import { Component, OnInit } from '@angular/core';
import { Users} from '../Model/app.user.model';
import {UserService} from '../services/app.user.services';
import {Response} from '@angular/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  message: string;
  user: Users;
 // userarr: Array<Users>;
  constructor(private a: UserService, private router: Router) {
    this.user = new Users('' , '');
    // this.userarr = new Array<Users>();
  }
  ngOnInit() {
  }

  login( ): void {
    {
     // console.log("data in component is*******"+JSON.stringify(this.user))
      this.a.verifyUser(this.user).subscribe(
        (resp: Response) => {
          console.log('resp is +++++');
          console.log(resp.json().data);
          console.log('token is ========' + resp.json().token);
          if (resp.json().authenticated) {
            sessionStorage.setItem('token', resp.json().token);
           
            sessionStorage.setItem('userid', resp.json().data.UserId);
           
            if (resp.json().data.UserType === "A") {
          
              // spefify here page name which we want to display
               this.router.navigate(['\dashboard']);
            }
          }
        },
        error => {
          console.log(`Error occured ${error}`);
        }
      );
      }
    }
  }

import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import { Observable} from 'rxjs';
 import { UsersCreate } from '../model/app.users.model';

@Injectable()
export class GetUserService {
   url: string;
constructor(private http: Http) {
   this.url = 'http://localhost:3000';

}

getusers(): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({'Content-Type': 'application/json'});
    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.get(`${this.url}/api/getacesusers`,
    options);
    console.log("in service"+JSON.stringify(resp));
    return resp;
}
}
import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import { Observable} from 'rxjs';
import { PersonInfo } from '../model/app.person.model';

@Injectable()
export class PersonCreateService {
   url: string;
constructor(private http: Http) {
   this.url = 'http://localhost:3000';

}

CreatePerson(role: PersonCreateService): Observable<Response> {
   let resp: Observable<Response>;
   const header: Headers = new Headers({'Content-Type': 'application/json'});
   const options: RequestOptions = new RequestOptions();
   options.headers = header;
   resp = this.http.post(`${this.url}/api/reg`,
   JSON.stringify(role),
   options);
   console.log(JSON.stringify(resp));
   return resp;
}
}
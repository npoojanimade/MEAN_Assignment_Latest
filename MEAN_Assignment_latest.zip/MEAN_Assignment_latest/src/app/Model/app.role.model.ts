export class UserRole {
  constructor(

      public Name: string,
      public MobNum: string,
      public Email: string,
      public Role: string
  ) {}
}

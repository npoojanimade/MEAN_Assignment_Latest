export class Users {
  constructor(

      public UserName: string,
      public PassWord: string
  ) {}
}

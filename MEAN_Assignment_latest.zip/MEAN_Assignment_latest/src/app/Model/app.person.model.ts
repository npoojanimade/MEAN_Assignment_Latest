export class PersonInfo {
    constructor(
  
        FullName :{
            FirstName: string,
            MiddleName: string,
            LastName:string
        },
        Gender: string,
        DateOfBirth: string,
        Age:  string, 
        Address: {
            FlatNumber: string,
            SocietyName: string,
            AreaName: string
          },
        Email: string,
        City: string,
        State: string,
        Pincode: string,
        PhoneNo:string,                 
        MobileNo:string,
        PhysicalDisability:string,                 
        MaritalStatus:string,
        Education: string,
        BirthSign:string,                       
        isAuthorized: string,
        Usr_Id:string 
    ) {}
  }